import triangulation

def main():
    # Create an instance of the triangulation class.
    triangulator = triangulation.Triangulation(simulate_tower_down=True, resolution=1.0, variance=2.0)
    
    # Generate valid readings ensuring that all circles have a common intersection.
    triangulator.generate_random_readings()
    
    # Triangulate the position based on the available (or down-adjusted) towers.
    triangulator.triangulate()
    
    # Plot the towers (with circles) and the estimated position.
    triangulator.plot()

if __name__ == "__main__":
    main()
