import os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.image import Image
import main

class TriangulationWidget(BoxLayout):
    def __init__(self, **kwargs):
        super(TriangulationWidget, self).__init__(**kwargs)
        self.orientation = 'vertical'
        
        # Button to run triangulation
        self.button = Button(text='Run Triangulation', size_hint=(1, 0.2))
        self.button.bind(on_press=self.run_triangulation)
        self.add_widget(self.button)
        
        # Initialize image widget without an image if file doesn't exist
        initial_source = "triangulation.png" if os.path.exists("triangulation.png") else ""
        self.img = Image(source=initial_source, size_hint=(1, 0.8))
        self.add_widget(self.img)
    
    def run_triangulation(self, instance):
        # Disable the button to prevent multiple clicks
        self.button.disabled = True
        # Run the main function from main.py, which generates and saves the plot
        main.main()
        # Update the image widget to display the new plot (if the file exists)
        self.update_image()
        self.button.disabled = False
    
    def update_image(self):
        # Check if the file exists, and update the image widget accordingly
        if os.path.exists("triangulation.png"):
            self.img.source = "triangulation.png"
            self.img.reload()
        else:
            self.img.source = ""
            self.img.reload()

class TriangulationApp(App):
    def build(self):
        return TriangulationWidget()

if __name__ == '__main__':
    TriangulationApp().run()
