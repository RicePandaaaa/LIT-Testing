import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import least_squares
import random
from rssi_simulator import RSSI_Simulator

class Triangulation:
    def __init__(self, simulate_tower_down=True, resolution=1.0, variance=2.0):
        """
        Initializes the triangulation class.
        
        Args:
            simulate_tower_down (bool): If True, randomly remove one tower from triangulation.
            resolution (float): Grid resolution (in feet) for checking common intersection.
            variance (float): Variance for random RSSI readings.
        """
        # Define tower positions in a 300 ft x 300 ft square
        tower_positions = {
            "Tower 1": np.array([0, 0]),
            "Tower 2": np.array([300, 0]),
            "Tower 3": np.array([0, 300]),
            "Tower 4": np.array([300, 300])
        }
        self.tower_positions = tower_positions
        self.simulate_tower_down = simulate_tower_down
        self.resolution = resolution
        self.variance = variance
        self.simulator = None
        self.towers_for_triangulation = None
        self.estimated_position = None
        self.down_tower = None  # To store the tower that is down (if any)

        self.simulator = RSSI_Simulator(RSSI_NAUGHT=-40, n=2.0)

    def generate_random_readings(self):
        """
        Generates random readings for all towers.
        """

        self.simulator.generate_random_readings(self.variance)

    def select_towers_for_triangulation(self):
        """
        Select towers to use for triangulation. Optionally simulates one tower being down.
        """

        self.towers_for_triangulation = self.simulator.towers.copy()
        self.down_tower = None
        if self.simulate_tower_down:
            self.down_tower = random.choice(self.towers_for_triangulation)
            print(f"Simulating {self.down_tower} being down.")
            self.towers_for_triangulation.remove(self.down_tower)

    def triangulate(self):
        """
        Triangulates the estimated device position using least squares optimization.
        Uses the towers selected (which might be fewer than four if one is down).
        """

        # Select the towers to use for triangulation.
        self.select_towers_for_triangulation()

        # Get and output the average distance for each tower.
        distances = {}
        for tower in self.towers_for_triangulation:
            avg_distance = self.simulator.get_average_distance(tower)
            distances[tower] = avg_distance
            print(f"{tower}: Average Distance = {avg_distance:.2f} ft")
        
        # Define the residuals function for least squares optimization.
        def residuals(point):
            return [
                np.linalg.norm(point - self.tower_positions[tower]) - distances[tower]
                for tower in self.towers_for_triangulation
            ]
        
        # Guess the center then adjust with least squares.
        initial_guess = np.array([150.0, 150.0])
        result = least_squares(residuals, initial_guess)
        self.estimated_position = result.x
        print(f"Estimated position: {self.estimated_position}")
        return self.estimated_position

    def plot(self):
        """
        Plots each tower as a colored dot (each tower a different color) with a circle 
        (radius = average distance) and the estimated device position as a red dot.
        The down tower (if any) does not have a circle drawn around it.
        Each tower is labeled with its number (e.g. 1 for Tower 1).
        """
        fig, ax = plt.subplots()
        tower_colors = ['blue', 'green', 'orange', 'purple']

        # Plot each tower.
        for i, tower in enumerate(self.simulator.towers):
            pos = self.tower_positions[tower]
            avg_distance = self.simulator.get_average_distance(tower)
            color = tower_colors[i % len(tower_colors)]
            # Plot the tower as a dot.
            ax.plot(pos[0], pos[1], 'o', markersize=8, color=color)
            # Label the tower with just its number.
            tower_label = tower.split()[-1]  # e.g., "Tower 1" -> "1"
            ax.text(pos[0] + 5, pos[1] + 5, tower_label, fontsize=12, color=color)
            # Draw circle only if this tower is not the down tower.
            if self.down_tower is not None and self.down_tower == tower:
                continue
            circle = plt.Circle((pos[0], pos[1]), avg_distance, color=color, fill=False)
            ax.add_artist(circle)
        
        # Plot the estimated position as a red dot.
        if self.estimated_position is not None:
            ax.plot(self.estimated_position[0], self.estimated_position[1], 'ro', markersize=10)
        
        ax.set_title("Triangulation based on RSSI")
        ax.set_xlabel("X (ft)")
        ax.set_ylabel("Y (ft)")
        ax.set_xlim(-50, 350)
        ax.set_ylim(-50, 350)
        ax.set_aspect('equal', 'box')

        # Save and show the plot.
        plt.savefig("triangulation.png")
        # Uncomment to show the plot.
        #plt.show()

# Example usage:
def main():
    triangulator = Triangulation(simulate_tower_down=True, resolution=1.0, variance=2.0)
    triangulator.generate_random_readings()
    triangulator.triangulate()
    triangulator.plot()

if __name__ == "__main__":
    main()
